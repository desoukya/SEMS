(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var colors;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/nooitaf_colors/export.js                                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
this.colors = Npm.require('colors');                                 // 1
colors = this.colors;                                                // 2
delete this.colors;                                                  // 3
                                                                     // 4
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nooitaf:colors'] = {
  colors: colors
};

})();

//# sourceMappingURL=nooitaf_colors.js.map

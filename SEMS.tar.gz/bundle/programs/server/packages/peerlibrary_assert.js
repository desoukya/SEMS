(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var assert;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/peerlibrary_assert/packages/peerlibrary_assert.js             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/peerlibrary:assert/server.js                             //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
assert = Npm.require('assert');                                      // 1
///////////////////////////////////////////////////////////////////////   // 10
                                                                          // 11
}).call(this);                                                            // 12
                                                                          // 13
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['peerlibrary:assert'] = {
  assert: assert
};

})();

//# sourceMappingURL=peerlibrary_assert.js.map

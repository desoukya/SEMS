(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['sems:momentum'] = {};

})();

//# sourceMappingURL=sems_momentum.js.map

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var ReactiveAggregate;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// packages/jcbernack_reactive-aggregate/aggregate.js                                       //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
ReactiveAggregate = function (sub, collection, pipeline, options) {                         // 1
  var defaultOptions = {                                                                    // 2
    observeSelector: {},                                                                    // 3
    clientCollection: collection._name                                                      // 4
  };                                                                                        // 5
  options = _.extend(defaultOptions, options);                                              // 6
                                                                                            // 7
  var initializing = true;                                                                  // 8
  sub._ids = {};                                                                            // 9
  sub._iteration = 1;                                                                       // 10
                                                                                            // 11
  function update() {                                                                       // 12
    if (initializing) return;                                                               // 13
    // add and update documents on the client                                               // 14
    collection.aggregate(pipeline).forEach(function (doc) {                                 // 15
      if (!sub._ids[doc._id]) {                                                             // 16
        sub.added(options.clientCollection, doc._id, doc);                                  // 17
      } else {                                                                              // 18
        sub.changed(options.clientCollection, doc._id, doc);                                // 19
      }                                                                                     // 20
      sub._ids[doc._id] = sub._iteration;                                                   // 21
    });                                                                                     // 22
    // remove documents not in the result anymore                                           // 23
    _.forEach(sub._ids, function (v, k) {                                                   // 24
      if (v != sub._iteration) {                                                            // 25
        delete sub._ids[k];                                                                 // 26
        sub.removed(options.clientCollection, k);                                           // 27
      }                                                                                     // 28
    });                                                                                     // 29
    sub._iteration++;                                                                       // 30
  }                                                                                         // 31
                                                                                            // 32
  // track any changes on the collection used for the aggregation                           // 33
  var query = collection.find(options.observeSelector);                                     // 34
  var handle = query.observeChanges({                                                       // 35
    added: update,                                                                          // 36
    changed: update,                                                                        // 37
    removed: update,                                                                        // 38
    error: function (err) {                                                                 // 39
      throw err;                                                                            // 40
    }                                                                                       // 41
  });                                                                                       // 42
  // observeChanges() will immediately fire an "added" event for each document in the query
  // these are skipped using the initializing flag                                          // 44
  initializing = false;                                                                     // 45
  // send an initial result set to the client                                               // 46
  update();                                                                                 // 47
  // mark the subscription as ready                                                         // 48
  sub.ready();                                                                              // 49
                                                                                            // 50
  // stop observing the cursor when the client unsubscribes                                 // 51
  sub.onStop(function () {                                                                  // 52
    handle.stop();                                                                          // 53
  });                                                                                       // 54
};                                                                                          // 55
                                                                                            // 56
//////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jcbernack:reactive-aggregate'] = {
  ReactiveAggregate: ReactiveAggregate
};

})();

//# sourceMappingURL=jcbernack_reactive-aggregate.js.map

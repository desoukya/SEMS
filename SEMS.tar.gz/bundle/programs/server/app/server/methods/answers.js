(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/answers.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
  createAnswer: function (answerData) {                                // 2
    var description = answerData.description;                          //
    var questionId = answerData.questionId;                            //
                                                                       //
    var answer = {                                                     // 5
      ownerId: Meteor.userId(),                                        // 6
      description: description,                                        // 7
      upvotes: [],                                                     // 8
      downvotes: [],                                                   // 9
      createdAt: Date.now()                                            // 10
    };                                                                 //
                                                                       //
    // Add the new answer and get the id                               //
    var answerId = Answers.insert(answer);                             // 14
                                                                       //
    // Append the answer to the question                               //
    Questions.update({ _id: questionId }, { $push: { answers: answerId } });
  },                                                                   //
                                                                       //
  deleteAnswer: function (answerId) {                                  // 21
    var answer = Answers.findOne({ _id: answerId });                   // 22
    var userId = Meteor.userId();                                      // 23
                                                                       //
    if (!answer) throw new Meteor.Error(404, "The answer you are trying to delete is not found");
                                                                       //
    if (userId === answer.ownerId || Roles.userIsInRole(userId, [ADMIN, LECTURER, TA])) {
      Questions.update({ answers: answerId }, { $pull: { answers: answerId } });
      Answers.remove({ _id: answerId });                               // 30
    } else throw new Meteor.Error(401, "You are not authorized to delete this answer");
  },                                                                   //
                                                                       //
  updateAnswer: function (answerData) {                                // 36
    var answerId = answerData.answerId;                                //
    var description = answerData.description;                          //
                                                                       //
    var answer = Answers.findOne({ _id: answerId });                   // 38
    var userId = Meteor.userId();                                      // 39
                                                                       //
    if (!answer) throw new Meteor.Error(404, "The answer you are trying to edit is not found");
                                                                       //
    if (userId === answer.ownerId || Roles.userIsInRole(userId, [ADMIN, LECTURER, TA, JTA])) {
      Answers.update({ _id: answerId }, { $set: { description: description } });
    } else throw new Meteor.Error(401, "You are not authorized to edit this answer");
  },                                                                   //
                                                                       //
  upvoteAnswer: function (answerId) {                                  // 52
    var answer = Answers.findOne({ _id: answerId });                   // 53
    var userId = Meteor.userId();                                      // 54
    var upvotes = answer.upvotes.map(function (x) {                    // 55
      return x.ownerId;                                                // 57
    });                                                                //
                                                                       //
    if (!answer) throw new Meteor.Error(404, 'The Answer you are upvoting is not found');
                                                                       //
    if (answer.ownerId === userId) throw new Meteor.Error(401, 'You are not allowed to upvote your own answer');
                                                                       //
    var upvote = { 'ownerId': userId, 'createdAt': Date.now() };       // 66
                                                                       //
    if (_.contains(upvotes, userId)) // Upvoted already, remove from upvoters
      Answers.update({ _id: answerId }, { $pull: { 'upvotes': { 'ownerId': userId } } });else {
      // Upvote and remove from downvoters                             //
      Answers.update({ _id: answerId }, { $push: { 'upvotes': upvote } });
      Answers.update({ _id: answerId }, { $pull: { 'downvotes': { 'ownerId': userId } } });
    }                                                                  //
  },                                                                   //
                                                                       //
  downvoteAnswer: function (answerId) {                                // 78
    var answer = Answers.findOne({ _id: answerId });                   // 79
    var userId = Meteor.userId();                                      // 80
    var downvotes = answer.downvotes.map(function (x) {                // 81
      return x.ownerId;                                                // 83
    });                                                                //
                                                                       //
    if (!answer) throw new Meteor.Error(404, 'The Answer you are downvoting is not found');
                                                                       //
    if (answer.ownerId === userId) throw new Meteor.Error(401, 'You are not that bad, don\'t downvote your answer');
                                                                       //
    var downvote = { 'ownerId': userId, 'createdAt': Date.now() };     // 92
                                                                       //
    if (_.contains(downvotes, userId)) // Downvoted already, remove from downvoters
      Answers.update({ _id: answerId }, { $pull: { 'downvotes': { 'ownerId': userId } } });else {
      // Downvote and remove from upvoters                             //
      Answers.update({ _id: answerId }, { $push: { 'downvotes': downvote } });
      Answers.update({ _id: answerId }, { $pull: { 'upvotes': { 'ownerId': userId } } });
    }                                                                  //
  },                                                                   //
                                                                       //
  markBestAnswer: function (data) {                                    // 103
    var questionId = data.questionId;                                  //
    var answerId = data.answerId;                                      //
    var marked = data.marked;                                          //
                                                                       //
    var answer = Answers.findOne({ _id: answerId });                   // 105
    var question = Questions.findOne({ _id: questionId });             // 106
                                                                       //
    if (!question || !answer) throw new Meteor.Error(404, "Resource not found");
                                                                       //
    // Remove best answer from all other answers                       //
    var answersIds = question.answers;                                 // 112
                                                                       //
    answersIds.forEach(function (id) {                                 // 114
      Answers.update({ _id: id }, { $set: { bestAnswer: false } });    // 115
    });                                                                //
                                                                       //
    // Toggle the current answer's bestAnswer flag                     //
    marked = !marked;                                                  // 119
                                                                       //
    Answers.update({ _id: answerId }, { $set: { bestAnswer: marked } });
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=answers.js.map

(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/announcements.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// ES6                                                                 //
Meteor.methods({                                                       // 2
  createAnnouncement: function (announcement) {                        // 3
    // TODO: Check the arguments passed from client - Never Trusted !  //
                                                                       //
    var title = announcement.title;                                    //
    var ownerId = announcement.ownerId;                                //
    var description = announcement.description;                        //
    var global = announcement.global;                                  //
    var milestone = announcement.milestone;                            //
    var teams = announcement.teams;                                    //
                                                                       //
    announcement.createdAt = Date.now();                               // 8
                                                                       //
    if (Roles.userIsInRole(Meteor.userId(), [ADMIN, LECTURER, TA])) {  // 10
      var _ret = (function () {                                        //
        var announcementId = Announcements.insert(announcement);       // 11
                                                                       //
        if (global) teams = Teams.find({}, {                           // 13
          _id: 1                                                       // 15
        }).fetch().map(function (team) {                               //
          return team._id;                                             // 17
        });                                                            //
                                                                       //
        teams.forEach(function (teamId) {                              // 20
                                                                       //
          var team = Teams.findOne({ _id: teamId });                   // 22
                                                                       //
          var members = team.members;                                  // 24
          var link = milestone ? '/milestones/' + announcementId : '/teams/' + team.slug + '/announcements';
          var typeHint = milestone ? 'Milestone :' : 'Announcement :';
          var icon = milestone ? '<i class="idea icon"></i>' : '<i class="announcement icon"></i>';
                                                                       //
          members.forEach(function (id) {                              // 29
            Notifications.insert({                                     // 30
              ownerId: id,                                             // 31
              content: icon + ' ' + typeHint + ' ' + title,            // 32
              link: link,                                              // 33
              read: false,                                             // 34
              createdAt: Date.now()                                    // 35
            });                                                        //
          });                                                          //
        });                                                            //
                                                                       //
        return {                                                       // 41
          v: announcementId                                            //
        };                                                             //
      })();                                                            //
                                                                       //
      if (typeof _ret === 'object') return _ret.v;                     //
    } else throw new Meteor.Error(401, 'Not authorized to create an Announcement');
  },                                                                   //
                                                                       //
  updateAnnouncement: function (data) {                                // 46
    // TODO: Check the arguments passed from client - Never Trusted !  //
    if (Roles.userIsInRole(Meteor.userId(), [ADMIN, LECTURER, TA])) {  // 48
      return Announcements.update({ _id: data._id }, { $set: data.announcement });
    } else throw new Meteor.Error(401, 'Not authorized to edit an Announcement');
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=announcements.js.map

(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/environment.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
  getNodeEnv: function () {                                            // 2
    return Meteor.settings.environment;                                // 3
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=environment.js.map

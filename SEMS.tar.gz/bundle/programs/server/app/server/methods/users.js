(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/users.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// ES6                                                                 //
                                                                       //
Meteor.methods({                                                       // 3
  registerUser: function (userData) {                                  // 4
                                                                       //
    var profile = {                                                    // 6
      firstName: userData.firstName,                                   // 7
      lastName: userData.lastName,                                     // 8
      GUCId: userData.GUCId,                                           // 9
      tutorialGroup: userData.tutorialGroup,                           // 10
      mobile: userData.mobile,                                         // 11
      githubUser: userData.githubUser                                  // 12
    };                                                                 //
                                                                       //
    if (userData.publicEmail) profile.publicEmail = userData.email;    // 15
                                                                       //
    var userId = Accounts.createUser({                                 // 19
      email: userData.email,                                           // 20
      password: userData.password,                                     // 21
      profile: profile                                                 // 22
    });                                                                //
                                                                       //
    if (userId) {                                                      // 25
      // Default Role, should be added after a successful creation     //
      Roles.addUsersToRoles(userId, STUDENT);                          // 27
                                                                       //
      Accounts.sendVerificationEmail(userId);                          // 29
                                                                       //
      return userId;                                                   // 31
    } else throw new Meteor.Error(400, 'Can\'t create new user');      //
  },                                                                   //
                                                                       //
  updateProfile: function (userData) {                                 // 38
    if (UserUtils.isLoggedIn()) {                                      // 39
      var user = Meteor.user();                                        // 40
      var profile = user.profile;                                      // 41
                                                                       //
      var digest = Package.sha.SHA256(userData.currentPass);           // 43
      check(digest, String);                                           // 44
                                                                       //
      var password = {                                                 // 46
        digest: digest,                                                // 47
        algorithm: 'sha-256'                                           // 48
      };                                                               //
                                                                       //
      var result = Accounts._checkPassword(user, password);            // 51
                                                                       //
      if (result.error == null) {                                      // 53
        // Password update is handled on client                        //
                                                                       //
        profile.firstName = userData.firstName;                        // 56
        profile.lastName = userData.lastName;                          // 57
        profile.GUCId = userData.GUCId;                                // 58
        profile.tutorialGroup = userData.tutorialGroup;                // 59
        profile.mobile = userData.mobile;                              // 60
        profile.githubUser = userData.githubUser;                      // 61
                                                                       //
        //add public email if it's public                              //
        if (userData.publicEmail) profile.publicEmail = Meteor.user().emails[0].address;
                                                                       //
        Meteor.users.update(user._id, {                                // 67
          $set: {                                                      // 68
            profile: profile                                           // 69
          }                                                            //
        });                                                            //
                                                                       //
        //delete public email if it's private                          //
        if (!userData.publicEmail) {                                   // 74
          Meteor.users.update({ _id: Meteor.userId() }, {              // 75
            $unset: {                                                  // 76
              'profile.publicEmail': ''                                // 77
            }                                                          //
          });                                                          //
        }                                                              //
      } else throw result.error;                                       //
    }                                                                  //
  },                                                                   //
                                                                       //
  resendVerification: function (userId) {                              // 88
    if (Meteor.userId() === userId) {                                  // 89
      Accounts.sendVerificationEmail(userId);                          // 90
    }                                                                  //
  },                                                                   //
                                                                       //
  removeUser: function (userId) {                                      // 94
    //TODO: Remove questions and answers by user                       //
                                                                       //
    if (Roles.userIsInRole(Meteor.userId(), ADMIN)) {                  // 97
      // Remove user from any team                                     //
      Teams.update({ members: userId }, { $pull: { members: userId } });
                                                                       //
      // Remove the user                                               //
      Meteor.users.remove({ _id: userId });                            // 102
    } else throw new Meteor.Error(401, "Can't perform this action");   //
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=users.js.map

(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/teams.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// ES6                                                                 //
Meteor.methods({                                                       // 2
  createTeam: function (team) {                                        // 3
                                                                       //
    var alreadyCreated = Teams.findOne({ members: Meteor.userId() });  // 5
                                                                       //
    if (alreadyCreated) throw new Meteor.Error(409, 'Team was already created by this user');else if (!Roles.userIsInRole(Meteor.userId(), SCRUM)) throw new Meteor.Error(401, "Not authorized to create a new team");else return Teams.insert(team);
  },                                                                   //
                                                                       //
  getTeamMembers: function (teamId) {                                  // 16
                                                                       //
    var usersIds = Teams.findOne({ _id: teamId }).members;             // 18
                                                                       //
    return Meteor.users.find({                                         // 20
      _id: {                                                           // 21
        $in: usersIds                                                  // 22
      }                                                                //
    });                                                                //
  },                                                                   //
                                                                       //
  removeFromTeam: function (userId, teamId) {                          // 27
    // Should be an admin,lecturer or a TA or a scrum of this team     //
    if (Roles.userIsInRole(Meteor.userId(), [ADMIN, LECTURER, TA]) || Roles.userIsInRole(Meteor.userId(), SCRUM) && TeamUtils.isMember(Meteor.userId(), teamId)) {
                                                                       //
      // Actually removes him if he is in multiple teams too           //
      Teams.update({                                                   // 34
        '_id': {                                                       // 35
          $in: Teams.find({                                            // 36
            members: userId                                            // 37
          }).fetch().map(function (item) {                             //
            return item._id;                                           // 39
          })                                                           //
        }                                                              //
      }, { $pull: { members: userId } }, { multi: true });             //
    }                                                                  //
  },                                                                   //
                                                                       //
  addMemberToTeam: function (userId, teamId) {                         // 48
    if (Roles.userIsInRole(Meteor.userId(), SCRUM) && TeamUtils.isMember(Meteor.userId(), teamId) || Roles.userIsInRole(Meteor.userId(), ADMIN)) {
      // If he is the scrum of this team or an admin he can add members
      var team = Teams.findOne({ _id: teamId });                       // 52
                                                                       //
      if (team.members.length >= 8) {                                  // 54
        // FIXME: Which http code here -_-                             //
        throw new Meteor.Error(403, 'Team size can\'t exceed 8 members');
      }                                                                //
                                                                       //
      // Getting the member                                            //
      var member = Meteor.users.findOne({                              // 60
        _id: userId,                                                   // 61
        roles: 'student'                                               // 62
      });                                                              //
                                                                       //
      if (!!member && !TeamUtils.isInTeam(userId)) {                   // 65
        Teams.update({ _id: teamId }, { $push: { members: userId } }, function (err, res) {
                                                                       //
          Email.send({                                                 // 68
            to: member.email(),                                        // 69
            from: Meteor.settings.systemEmail,                         // 70
            subject: '[SEMS] You have joined a team !',                // 71
            text: 'Hello ' + member.profile.firstName + ', Your scrum master just added you to your team "' + team.name + '"'
          });                                                          //
                                                                       //
          return team;                                                 // 75
        });                                                            //
      } else {                                                         //
        throw new Meteor.Error(409, 'Can\'t add this member');         // 78
      }                                                                //
    } else throw new Meteor.Error(401, "You are not authorized to add members to this team");
  },                                                                   //
                                                                       //
  calculateDailyLeaderBoard: function () {                             // 85
    metrics = new Metrics(Meteor.settings.githubSecret);               // 86
    Teams.find({}, { fields: { repo: 1, metrics: 1, members: 1 } }).forEach(function (team) {
      if (!team.metrics) {                                             // 88
        Teams.update(team, { $push: { metrics: { totalWeeklyLines: 0, lineAdditions: 0, standardDev: 0, dailyPoints: 0, createdAt: Date.now() } } }, function (err, affected) {
          if (err) {                                                   // 91
            console.log("error while updating".red, err);              // 92
          } else {                                                     //
            console.log(affected + " documents affected");             // 94
          }                                                            //
        });                                                            //
      } else {                                                         //
        var additionsAndSubt = 0;                                      // 98
        metrics.weeklyCodeFrequency(team.repo, function (err, res) {   // 99
          if (!err) {                                                  // 100
            if (res.data.length > 0) {                                 // 101
              additionsAndSubt = res.data[res.data.length - 1][1] + -1 * res.data[res.data.length - 1][2];
            } else {                                                   //
              console.log("No entries in weekly code frequency".yellow);
            }                                                          //
          }                                                            //
        });                                                            //
                                                                       //
        var teamMembers = [];                                          // 110
        if (team.members.length < 1) {                                 // 111
          console.log("This team has no members".red);                 // 112
        } else {                                                       //
          for (var i = 0; i < team.members.length; i++) {              // 114
            var member = Meteor.users.findOne({ _id: team.members[i] }, { fields: { metrics: 1, profile: 1 } });
            teamMembers.push(member);                                  // 116
          }                                                            //
                                                                       //
          var contribStats = [];                                       // 119
          metrics.contributorsStatistics(team.repo, function (err, res) {
            if (!err) {                                                // 121
              contribStats = res.data;                                 // 122
            }                                                          //
          });                                                          //
                                                                       //
          var lineDiff = additionsAndSubt - team.metrics[team.metrics.length - 1].totalWeeklyLines;
          var average = lineDiff / teamMembers.length;                 // 127
          var cumulative = 0;                                          // 128
          for (var i = 0; i < teamMembers.length; i++) {               // 129
            var userTotalWeeklyLines = 0;                              // 130
            var userLineAdditions = 0;                                 // 131
            var found = false;                                         // 132
            for (var j = 0; j < contribStats.length; j++) {            // 133
              if (teamMembers[i].profile.githubUser == contribStats[j].author.login) {
                found = true;                                          // 135
                                                                       //
                userTotalWeeklyLines = contribStats[j].weeks[contribStats[j].weeks.length - 1].a + contribStats[j].weeks[contribStats[j].weeks.length - 1].c;
                                                                       //
                userLineAdditions = userTotalWeeklyLines - teamMembers[i].metrics[teamMembers[i].metrics.length - 1].totalWeeklyLines;
                break;                                                 // 142
              }                                                        //
            }                                                          //
            if (!found) {                                              // 145
              console.log('User did not make any commits or was not found in contributor List'.yellow);
            }                                                          //
                                                                       //
            Meteor.users.update(teamMembers[i], {                      // 149
              $push: {                                                 // 150
                metrics: {                                             // 151
                  totalWeeklyLines: userTotalWeeklyLines,              // 152
                  lineAdditions: userLineAdditions,                    // 153
                  createdAt: Date.now()                                // 154
                }                                                      //
              }                                                        //
            }, function (err, affected) {                              //
              if (err) {                                               // 158
                console.log("error while updating user with new metrics".red, err);
              } else {                                                 //
                console.log(affected + " users affected");             // 161
              }                                                        //
            });                                                        //
                                                                       //
            cumulative = cumulative + Math.pow(average - userLineAdditions, 2);
          }                                                            //
                                                                       //
          var variance = cumulative / teamMembers.length;              // 168
          var sd = Math.sqrt(variance);                                // 169
                                                                       //
          var newPoints = lineDiff - lineDiff * (sd / 1000);           // 172
          var updatedPoints = team.metrics[team.metrics.length - 1].dailyPoints + newPoints;
          Teams.update(team, {                                         // 174
            $push: {                                                   // 175
              metrics: {                                               // 176
                totalWeeklyLines: additionsAndSubt,                    // 177
                lineAdditions: lineDiff,                               // 178
                standardDev: sd,                                       // 179
                dailyPoints: updatedPoints,                            // 180
                createdAt: Date.now()                                  // 181
              }                                                        //
            }                                                          //
          }, function (err, affected) {                                //
            if (err) {                                                 // 185
              console.log("error while updating team with new metrics".red, err);
            } else {                                                   //
              console.log(affected + " teams affected");               // 188
            }                                                          //
          });                                                          //
        }                                                              //
      }                                                                //
    });                                                                //
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=teams.js.map

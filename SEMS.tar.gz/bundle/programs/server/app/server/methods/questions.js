(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/questions.js                                         //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
  deleteQuestion: function (questionId) {                              // 2
    var question = Questions.findOne({ _id: questionId });             // 3
    var userId = Meteor.userId();                                      // 4
                                                                       //
    if (!question) throw new Meteor.Error(404, 'The question you are trying to delete is not found');
                                                                       //
    if (userId === question.ownerId || Roles.userIsInRole(userId, [ADMIN, LECTURER, TA])) {
                                                                       //
      // Remove all answers related to this question                   //
      Answers.remove({ _id: { $in: question.answers } });              // 13
                                                                       //
      // Delete self                                                   //
      Questions.remove({ _id: questionId });                           // 16
    } else throw new Meteor.Error(401, 'You are not authorized to delete this question !');
  },                                                                   //
                                                                       //
  updateQuestion: function (questionData) {                            // 24
    var questionId = questionData.questionId;                          //
    var title = questionData.title;                                    //
    var description = questionData.description;                        //
    var tags = questionData.tags;                                      //
                                                                       //
    var userId = Meteor.userId();                                      // 26
    var question = Questions.findOne({ _id: questionId });             // 27
                                                                       //
    if (!question) throw new Meteor.Error(404, 'The question you are trying to update doesn\'t exist !');
                                                                       //
    if (userId === question.ownerId || Roles.userIsInRole(userId, [ADMIN, LECTURER, TA, JTA])) {
      Questions.update({ _id: questionId }, { $set: { title: title, description: description, tags: tags } });
    } else throw new Meteor.Error(401, 'You are not authorized to edit this question');
  },                                                                   //
                                                                       //
  upvoteQuestion: function (questionId) {                              // 39
    var question = Questions.findOne({ _id: questionId });             // 40
    var userId = Meteor.userId();                                      // 41
    var upvotes = question.upvotes.map(function (x) {                  // 42
      return x.ownerId;                                                // 44
    });                                                                //
                                                                       //
    if (!question) throw new Meteor.Error(404, 'The Question you are upvoting is not found');
                                                                       //
    if (question.ownerId === userId) throw new Meteor.Error(401, 'You are not allowed to upvote your own question');
                                                                       //
    var upvote = { 'ownerId': userId, 'createdAt': Date.now() };       // 53
                                                                       //
    if (_.contains(upvotes, userId)) // Upvoted already, remove from upvoters
      Questions.update({ _id: questionId }, { $pull: { 'upvotes': { 'ownerId': userId } } });else {
      // Upvote and remove from downvoters                             //
      Questions.update({ _id: questionId }, { $push: { 'upvotes': upvote } });
      Questions.update({ _id: questionId }, { $pull: { 'downvotes': { 'ownerId': userId } } });
    }                                                                  //
  },                                                                   //
                                                                       //
  downvoteQuestion: function (questionId) {                            // 65
    var question = Questions.findOne({ _id: questionId });             // 66
    var userId = Meteor.userId();                                      // 67
    var downvotes = question.downvotes.map(function (x) {              // 68
      return x.ownerId;                                                // 70
    });                                                                //
                                                                       //
    if (!question) throw new Meteor.Error(404, 'The Question you are downvoting is not found');
                                                                       //
    if (question.ownerId === userId) throw new Meteor.Error(401, 'You are not that bad, don\'t downvote your question');
                                                                       //
    var downvote = { 'ownerId': userId, 'createdAt': Date.now() };     // 79
                                                                       //
    if (_.contains(downvotes, userId)) // Downvoted already, remove from downvoters
      Questions.update({ _id: questionId }, { $pull: { 'downvotes': { 'ownerId': userId } } });else {
      // Downvote and remove from upvoters                             //
      Questions.update({ _id: questionId }, { $push: { 'downvotes': downvote } });
      Questions.update({ _id: questionId }, { $pull: { 'upvotes': { 'ownerId': userId } } });
    }                                                                  //
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=questions.js.map

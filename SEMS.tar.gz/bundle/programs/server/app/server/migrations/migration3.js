(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/migrations/migration3.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Migrations.add({                                                       // 1
  version: 3,                                                          // 2
  name: 'add team slugs',                                              // 3
  up: function () {                                                    // 4
                                                                       //
    teams = Teams.find({ slug: { $exists: false } });                  // 6
    teams.forEach(function (team) {                                    // 7
      Teams.update({ _id: team._id }, { $set: {} }, { validate: false });
    });                                                                //
  },                                                                   //
  down: function () {                                                  // 12
    Teams.update({}, { $unset: { friendlySlugs: 1, slug: 1 } }, { multi: true, validate: false });
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=migration3.js.map

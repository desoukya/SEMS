(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/migrations/migration2.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Migrations.add({                                                       // 1
  version: 2,                                                          // 2
  name: 'denormalize company into team',                               // 3
  up: function () {                                                    // 4
    Teams.find().fetch().forEach(function (team) {                     // 5
      console.log('------------- Migrating team : ' + team.name + '---------------');
      var newCompany = Companies.findOne({ _id: team.company });       // 7
      Teams.update({ _id: team._id }, { $set: { company: newCompany } }, { validate: false });
      console.log(team.company + " -> " + JSON.stringify(newCompany));
      console.log('-----------------------------------------------');  // 10
    });                                                                //
  },                                                                   //
  down: function () {                                                  // 14
    Teams.find().fetch().forEach(function (team) {                     // 15
      console.log('------------- Migrating team : ' + team.name + '---------------');
      var newCompany = team.company._id;                               // 17
      Teams.update({ _id: team._id }, { $set: { company: newCompany } }, { validate: false });
      console.log(JSON.stringify(team.company) + " -> " + team.company._id);
      console.log('-----------------------------------------------');  // 20
    });                                                                //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=migration2.js.map

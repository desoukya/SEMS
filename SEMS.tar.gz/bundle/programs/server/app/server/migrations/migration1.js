(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/migrations/migration1.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Migrations.add({                                                       // 1
  version: 1,                                                          // 2
  name: 'change createdAt field to count milli seconds',               // 3
  up: function () {                                                    // 4
                                                                       //
    var collections = [Announcements, Questions, Answers, Teams, Materials];
    collections.forEach(function (collection) {                        // 7
      console.log('Migrating collection ' + collection._name);         // 8
                                                                       //
      collection.find().fetch().forEach(function (document) {          // 10
        var oldDate = document.createdAt;                              // 11
        var newDate = Date.parse(oldDate);                             // 12
        if (!!parseInt(newDate)) {                                     // 13
          console.log(oldDate + " -> " + newDate);                     // 14
          collection.update({ _id: document._id }, { $set: { createdAt: newDate } }, { validate: false });
        } else console.log(oldDate, "couldn't parse old Date");        //
      });                                                              //
                                                                       //
      console.log('-----------------------------------------------');  // 20
    });                                                                //
  },                                                                   //
  down: function () {                                                  // 23
    var collections = [Announcements, Questions, Answers, Teams, Materials];
    collections.forEach(function (collection) {                        // 25
      console.log('Migrating collection ' + collection._name);         // 26
                                                                       //
      collection.find().fetch().forEach(function (document) {          // 28
        var oldDate = document.createdAt;                              // 29
        var newDate = moment(parseInt(oldDate)).toString();            // 30
                                                                       //
        if (!!parseInt(oldDate)) {                                     // 32
          console.log(oldDate + " -> " + newDate);                     // 33
          collection.update({ _id: document._id }, { $set: { createdAt: newDate } }, { validate: false });
        } else console.log(oldDate, " is not in the expected format");
        collection.update({ _id: document._id }, { $set: { createdAt: newDate } }, { validate: false });
        console.log(oldDate + " -> " + newDate);                       // 38
      });                                                              //
                                                                       //
      console.log('-----------------------------------------------');  // 41
    });                                                                //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=migration1.js.map

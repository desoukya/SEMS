(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/startup/metrics.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
//Calls function every 6 hours                                         //
Meteor.setInterval(function () {                                       // 2
  Meteor.call("calculateDailyLeaderBoard");                            // 3
}, 1000 * 60 * 60 * 6);                                                //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=metrics.js.map

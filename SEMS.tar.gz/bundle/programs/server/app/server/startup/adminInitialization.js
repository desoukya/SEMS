(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/startup/adminInitialization.js                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
  if (Meteor.users.find().count() === 0) {                             // 2
    // Creating a random password                                      //
    var pass = Random.id(20);                                          // 4
                                                                       //
    // Creating the great admin                                        //
    var userId = Accounts.createUser({                                 // 7
      email: Meteor.settings.adminEmail,                               // 8
      password: pass,                                                  // 9
      profile: {                                                       // 10
        firstName: 'System',                                           // 11
        lastName: 'Admin',                                             // 12
        GUCId: '00-00000',                                             // 13
        tutorialGroup: 'Adminstration'                                 // 14
      }                                                                //
    });                                                                //
                                                                       //
    if (userId) {                                                      // 19
      // Make em an admin !                                            //
      Roles.addUsersToRoles(userId, ADMIN);                            // 21
                                                                       //
      // He is a verified user for sure !                              //
      Meteor.users.update(userId, {                                    // 24
        $set: {                                                        // 25
          'emails.0.verified': true                                    // 26
        }                                                              //
      });                                                              //
                                                                       //
      Email.send({                                                     // 30
        to: Meteor.settings.adminEmail,                                // 31
        from: Meteor.settings.systemEmail,                             // 32
        subject: "[SEMS] Welcome Adminstrator",                        // 33
        text: 'Hello Admin, your account is created with the following password: ' + pass + '\nPlease Change your password after logging in'
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=adminInitialization.js.map

(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/startup/email.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
  // Pulling MAIL_URL from settings                                    //
  process.env.MAIL_URL = Meteor.settings.MAIL_URL;                     // 3
                                                                       //
  // From (ME !)                                                       //
  Accounts.emailTemplates.from = Meteor.settings.systemEmail;          // 6
                                                                       //
  Accounts.emailTemplates.siteName = 'SEMS';                           // 8
                                                                       //
  Accounts.emailTemplates.verifyEmail.subject = function (user) {      // 10
    return 'SEMS Account Verification';                                // 11
  };                                                                   //
                                                                       //
  // Email text                                                        //
  Accounts.emailTemplates.verifyEmail.text = function (user, url) {    // 15
    return 'Thank you for registering.  Please click on the following link to verify your email address: \r\n' + url;
  };                                                                   //
                                                                       //
  // Enable verification after account is created                      //
  Accounts.config({                                                    // 20
    sendVerificationEmail: true                                        // 21
  });                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=email.js.map

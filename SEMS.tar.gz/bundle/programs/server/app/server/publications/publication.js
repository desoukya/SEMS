(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/publication.js                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('users', function () {                                  // 1
  var roles = arguments.length <= 0 || arguments[0] === undefined ? ROLES : arguments[0];
                                                                       //
  // Checking that roles is an array of strings                        //
  check(roles, [String]);                                              // 4
                                                                       //
  var userId = this.userId;                                            // 6
  var user = Meteor.users.findOne(userId);                             // 7
                                                                       //
  var filter = {                                                       // 10
    fields: {                                                          // 11
      profile: 1,                                                      // 12
      roles: 1                                                         // 13
    }                                                                  //
  };                                                                   //
                                                                       //
  var selector = {};                                                   // 17
                                                                       //
  if (roles) {                                                         // 19
    var filteredRoles = [];                                            // 20
    _.each(roles, function (role) {                                    // 21
      if (_.contains(ROLES, role)) {                                   // 22
        filteredRoles.push(role);                                      // 23
      }                                                                //
    });                                                                //
                                                                       //
    selector['roles'] = {                                              // 28
      $in: filteredRoles                                               // 29
    };                                                                 //
  }                                                                    //
                                                                       //
  if (user) {                                                          // 34
    // Admins can have full access to users                            //
    if (Roles.userIsInRole(user, ADMIN)) {                             // 36
      filter = {};                                                     // 37
    }                                                                  //
                                                                       //
    return Meteor.users.find(selector, filter);                        // 40
  }                                                                    //
  // If user is not logged in return nothing to fire up ready()        //
  return [];                                                           // 43
});                                                                    //
                                                                       //
Meteor.publish('images', function () {                                 // 46
  return Images.find({});                                              // 47
});                                                                    //
                                                                       //
Meteor.publish('files', function () {                                  // 50
  return Files.find({});                                               // 51
});                                                                    //
                                                                       //
Meteor.publish('materials', function () {                              // 54
  return Materials.find({});                                           // 55
});                                                                    //
                                                                       //
Meteor.publish('teams', function () {                                  // 58
  return Teams.find({});                                               // 59
});                                                                    //
                                                                       //
Meteor.publish('leaderboardSortedTeams', function () {                 // 62
  ReactiveAggregate(this, Teams, [{ $unwind: "$metrics" }, { $group: { _id: "$_id", metrics: { $last: "$metrics" } } }, { $sort: { "metrics.dailyPoints": 1 } }]);
});                                                                    //
                                                                       //
Meteor.publish('companies', function () {                              // 70
  return Companies.find({});                                           // 71
});                                                                    //
                                                                       //
Meteor.publish('announcements', function () {                          // 74
  return Announcements.find({ milestone: { $ne: true } });             // 75
});                                                                    //
                                                                       //
Meteor.publish('milestones', function () {                             // 78
  return Announcements.find({ milestone: true });                      // 79
});                                                                    //
                                                                       //
Meteor.publish('allAnnouncements', function () {                       // 82
  return Announcements.find();                                         // 83
});                                                                    //
                                                                       //
Meteor.publish('questions', function () {                              // 86
  return Questions.find({});                                           // 87
});                                                                    //
                                                                       //
Meteor.publish("answers", function () {                                // 90
  return Answers.find({});                                             // 91
});                                                                    //
                                                                       //
Meteor.publish('notifications', function () {                          // 94
  return Notifications.find({ ownerId: this.userId });                 // 95
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publication.js.map
